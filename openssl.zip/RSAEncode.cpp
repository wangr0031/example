﻿#include "RSAEncode.h"

using namespace std;

bool RSAEncode::OpenPublicKey()
{
	RSA* rsa = NULL;

	OpenSSL_add_all_algorithms();
	BIO *bp = BIO_new(BIO_s_file());;
	BIO_read_filename(bp, keyfile(PUBLIC_KEY_FILE).c_str());
	if (NULL == bp)
	{
		cout << "open_public_key bio file new error!" << endl;
		return false;
	}

	rsa = PEM_read_bio_RSAPublicKey(bp, NULL, NULL, NULL);
	if (rsa == NULL)
	{
		cout << "open_public_key failed to PEM_read_bio_RSAPublicKey!" << endl;
		BIO_free(bp);
		RSA_free(rsa);

		return false;
	}

	//cout << "open_public_key success to PEM_read_bio_RSAPublicKey!" << endl;
	m_publicKey = EVP_PKEY_new();
	if(NULL == m_publicKey)
	{
		cout << "open_public_key EVP_PKEY_new failed" << endl;
		RSA_free(rsa);

		return false;
	}

	EVP_PKEY_assign_RSA(m_publicKey, rsa);

	OpenSSL_add_all_ciphers();

	m_publicCtx = EVP_PKEY_CTX_new(m_publicKey, NULL);
	if (NULL == m_publicCtx)
	{
		cout << "ras_pubkey_encryptfailed to open ctx." << endl;
		return false;
	}

	if (EVP_PKEY_encrypt_init(m_publicCtx) <= 0)
	{
		cout << "ras_pubkey_encrypt failed to EVP_PKEY_encrypt_init." << endl;
		return false;
	}

	return true;
}

bool RSAEncode::Initialize()
{
	if (!OpenPublicKey())
	{
		Clear();
		return false;
	}

	return true;
}

char* RSAEncode::EncodeRSAKey(const char* str, size_t& len)
{	
	memset(res, 0, RES_SIZE);

	if (EVP_PKEY_encrypt(m_publicCtx, NULL, &len, (const unsigned char*)str, strlen(str) + 1) <= 0 || len > RES_SIZE)
	{
		cout << "ras_pubkey_encrypt failed to EVP_PKEY_encrypt NULL." << endl;
		return NULL;
	}

	char out[RES_SIZE] = {0};
	
	if (EVP_PKEY_encrypt(m_publicCtx, (unsigned char*)out, &len, (const unsigned char*)str, strlen(str) + 1) <= 0)
	{
		cout << "ras_pubkey_encrypt failed to EVP_PKEY_encrypt." << endl;
		return NULL;
	}

	len = base64_encode(out, len, res);
	
	return res;
}

int RSAEncode::base64_encode(const char *in_str, int in_len, char *out_str)
{
	BIO *b64, *bio;
	BUF_MEM *bptr = NULL;
	size_t size = 0;

	if (in_str == NULL || out_str == NULL)
		return -1;

	b64 = BIO_new(BIO_f_base64());
	bio = BIO_new(BIO_s_mem());
	bio = BIO_push(b64, bio);

	BIO_write(bio, in_str, in_len);
	BIO_flush(bio);

	BIO_get_mem_ptr(bio, &bptr);
	memcpy(out_str, bptr->data, bptr->length);
	out_str[bptr->length] = '\0';
	size = bptr->length;

	BIO_free_all(bio);
	return size;
}



int main(int argc, char * argv[])
{
	char str[RES_SIZE] = {0};
	char* res;
	char* code;
	size_t len = 0;

	RSAEncode pRSAEncode;
	if (!pRSAEncode.Initialize())
		cout << "pRSAEncode.Initialize() failed!" << endl;
	cout << "Input the PASSWORD: ";
	cin >> str;

	cout << "PASSWORD:" << str << endl;

	if ((res = pRSAEncode.EncodeRSAKey(str, len)) != NULL)
		cout << "CODE:" << res << endl;

	return 0;
}
