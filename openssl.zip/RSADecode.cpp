﻿#include "RSADecode.h"
#include "TException.h"
#include <iostream>

using namespace std;

RSADecode* RSADecode::pInst = nullptr;

RSADecode& RSADecode::Instance()
{
    static RSADecode Inst;
    if (!pInst)
    {
        pInst = &Inst;
        if (!pInst->Init())
        {
            throw TException("RSADecode::Instance failed");
        }
    }
    return *pInst;
}

bool RSADecode::Init()
{
	if (!OpenPrivateKey())
	{
		Clear();
		return false;
	}

	return true;
}

std::string RSADecode::DecodeRSAKey(const char* str, size_t len)
{
	size_t i = 0;
	memset(res, 0, RES_SIZE);

	char out[RES_SIZE] = {0};

	len = base64_decode(str, len, out);

	if (EVP_PKEY_decrypt(m_privateCtx, NULL, &i, (const unsigned char*)out, len) <= 0)
	{
		cout << "ras_prikey_decrypt failed to EVP_PKEY_decrypt NULL." << endl;

		return "";
	}

	if (EVP_PKEY_decrypt(m_privateCtx, (unsigned char*)res, &i, (const unsigned char*)out, len) <= 0)
	{
		cout << "ras_prikey_decrypt failed to EVP_PKEY_decrypt." << endl;

		return "";
	}

	return res;
}

bool RSADecode::OpenPrivateKey()
{
    RSA* rsa = RSA_new();
    OpenSSL_add_all_algorithms();
    BIO* bp = NULL;
    bp = BIO_new_file(keyfile(PRIVATE_KEY_FILE).c_str(), "rb");
    if (NULL == bp)
    {
        cout << "open_private_key bio file new error!" << endl;
        return false;
    }

    rsa = PEM_read_bio_RSAPrivateKey(bp, NULL, NULL, (void *)RSA_PRIKEY_PSW);
    if (rsa == NULL)
    {
        cout << "open_private_key failed to PEM_read_bio_RSAPrivateKey!" << endl;
        BIO_free(bp);
        RSA_free(rsa);

        return false;
    }

    //cout << "open_private_key success to PEM_read_bio_RSAPrivateKey!" << endl;
    m_privateKey = EVP_PKEY_new();
    if (NULL == m_privateKey)
    {
        cout << "open_private_key EVP_PKEY_new failed" << endl;
        RSA_free(rsa);

        return NULL;
    }

    EVP_PKEY_assign_RSA(m_privateKey, rsa);


    OpenSSL_add_all_ciphers();

    m_privateCtx = EVP_PKEY_CTX_new(m_privateKey, NULL);
    if (NULL == m_privateCtx)
    {
        cout << "ras_prikey_decryptfailed to open ctx." << endl;
        return false;
    }

    if (EVP_PKEY_decrypt_init(m_privateCtx) <= 0)
    {
        cout << "ras_prikey_decryptfailed to EVP_PKEY_decrypt_init." << endl;
        return false;
    }

    return true;
}

int RSADecode::base64_decode(const char *in_str, int in_len, char *out_str)
{
	BIO *b64, *bio;
	BUF_MEM *bptr = NULL;
	int counts;
	int size = 0;

	if (in_str == NULL || out_str == NULL)
		return -1;

	b64 = BIO_new(BIO_f_base64());
	BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);

	bio = BIO_new_mem_buf((char*)in_str, in_len);
	bio = BIO_push(b64, bio);

	size = BIO_read(bio, out_str, in_len);
	out_str[size] = '\0';

	BIO_free_all(bio);
	return size;
}


