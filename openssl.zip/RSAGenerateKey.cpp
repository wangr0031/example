﻿#include "RSAGenerateKey.h"

using namespace std;

bool RSAGenerateKey::GenerateKeyFiles()
{
	RAND_seed(rnd_seed, sizeof(rnd_seed));

	RSA* rsa = RSA_generate_key(RSA_KEY_LENGTH, RSA_F4, NULL, NULL);

	if (rsa == NULL)
	{
		cout << "RSA_generate_key error!" << endl;
		return false;
	}

	// 开始生成公钥文件
	BIO* bp = BIO_new(BIO_s_file());

	if (bp == NULL)
	{
		cout << "Generate_key bio file new error!" << endl;
        return false;
	}

	if (BIO_write_filename(bp, (void *)(keyfile(PUBLIC_KEY_FILE).c_str())) <= 0)
	{
		cout << "BIO_write_filename error!" << endl;
		return false;
	}

	if (PEM_write_bio_RSAPublicKey(bp, rsa) != 1)
	{
		cout << "PEM_write_bio_RSAPublicKey error!" << endl;
		return false;
	}

	// 公钥文件生成成功，释放资源
	cout << "Create public key ok!" << endl;
	BIO_free_all(bp);

	// 生成私钥文件
	bp = BIO_new_file(keyfile(std::string(PRIVATE_KEY_FILE).c_str()).c_str(), "w+");
	if (NULL == bp)
	{
		cout << "generate_key bio file new error2!" << endl;
		return false;
	}

	if (PEM_write_bio_RSAPrivateKey(bp, rsa, EVP_des_ede3_ofb(), (unsigned char *)RSA_PRIKEY_PSW, sizeof(RSA_PRIKEY_PSW) - 1, NULL, NULL) != 1)
	{
		cout << "PEM_write_bio_RSAPublicKey error!" << endl;
		return false;
	}
		
	// 释放资源

	cout << "Create private key ok!" << endl;

	BIO_free_all(bp);
	RSA_free(rsa);

	return true;
}

int main(int argc, char * argv[])
{
	RSAGenerateKey rasGenerateKey;

	if (!rasGenerateKey.GenerateKeyFiles())
		cout << "Create key error! " << endl;

	return 0;
}
