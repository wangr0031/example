﻿/***********************************************************
*
*   Copyright (c) 2003-2017  ZTEsoft Technology Co.,Ltd.
*
*   All rights reserved.
*
*   文件名称：RSADecode.h  
*
*   简要描述: RSA密钥解码
*
*   
*
*   当前版本：1.0
*
*   作者/修改者：梁师师  liang.shishi@zte.com.cn
*
*   完成日期：2017/06/07
*
*   修订说明：
*
************************************************************/

#ifndef RSADECODE_H_
#define RSADECODE_H_

#include "EnvDefine.h"
#include <string>

class RSADecode
{
public:
    static RSADecode& Instance();

	std::string DecodeRSAKey(const char* str, size_t len);

private:
	RSADecode() { m_privateKey = NULL; m_privateCtx = NULL; }
	~RSADecode() { Clear(); }
	bool Init();
	bool OpenPrivateKey();
	void Clear() 
	{ 
		EVP_PKEY_CTX_free(m_privateCtx);
	}
	int base64_decode(const char *in_str, int in_len, char *out_str);

private:
	static RSADecode* pInst;
	EVP_PKEY* m_privateKey;
	EVP_PKEY_CTX* m_privateCtx;
	char res[RES_SIZE];
};

#endif
