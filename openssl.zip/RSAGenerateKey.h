﻿/***********************************************************
*
*   Copyright (c) 2003-2017  ZTEsoft Technology Co.,Ltd.
*
*   All rights reserved.
*
*   文件名称：RSAGenerateKey.h
*
*   简要描述: 生成OpenSSL RSA密钥和公钥
*
*   
*
*   当前版本：1.0
*
*   作者/修改者：梁师师  liang.shishi@zte.com.cn
*
*   完成日期：2017/06/07
*
*   修订说明：
*
************************************************************/

#ifndef RSAGENERATEKEY_H_
#define RSAGENERATEKEY_H_

#include "EnvDefine.h"

static const char rnd_seed[] = "string to make the random number generator initialized";

class RSAGenerateKey
{
public:
	RSAGenerateKey() {}
	~RSAGenerateKey() {}

	bool GenerateKeyFiles();
};

#endif

