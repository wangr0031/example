﻿/***********************************************************
*
*   Copyright (c) 2003-2017  ZTEsoft Technology Co.,Ltd.
*
*   All rights reserved.
*
*   文件名称：RSAEncode.h 

*   简要描述: RSA公钥编码
*
*   
*
*   当前版本：1.0
*
*   作者/修改者：梁师师  liang.shishi@zte.com.cn
*
*   完成日期：2017/06/07
*
*   修订说明：
*
************************************************************/

#ifndef RSAENCODE_H_
#define RSAENCODE_H_

#include "EnvDefine.h"

class RSAEncode
{
public:
	RSAEncode() { m_publicKey = NULL; m_publicCtx = NULL; }
	~RSAEncode() { Clear(); }

	bool Initialize();
	char* EncodeRSAKey(const char* str, size_t& len);

private:
	bool OpenPublicKey();
	void Clear() { EVP_PKEY_CTX_free(m_publicCtx);EVP_PKEY_free(m_publicKey);  }
	int base64_encode(const char *in_str, int in_len, char *out_str);

private:
	EVP_PKEY* m_publicKey;
	EVP_PKEY_CTX* m_publicCtx;
	char res[RES_SIZE];
};

#endif
