﻿/***********************************************************
*
*   Copyright (c) 2003-2017  ZTEsoft Technology Co.,Ltd.
*
*   All rights reserved.
*
*   文件名称：EnvDefine.h 
*
*   简要描述: 公共环境变量
*
*   
*
*   当前版本：1.0
*
*   作者/修改者：梁师师  liang.shishi@zte.com.cn
*
*   完成日期：2017/06/07
*
*   修订说明：
*
************************************************************/

#ifndef ENVDEFINE_H_
#define ENVDEFINE_H_

#include <iostream>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>


#define RSA_KEY_LENGTH 256

#define RES_SIZE RSA_KEY_LENGTH

#define PRIVATE_KEY_FILE "OCSPrivateKey.pem"
#define PUBLIC_KEY_FILE "OCSPublicKey.pem"

#define RSA_PRIKEY_PSW "ztesoft$123"

auto keyfile = [] (const char* ss) -> std::string { char sTmp[64] = {0}; snprintf(sTmp, sizeof(sTmp), "%s/etc/%s", getenv("HOME"), ss); return sTmp; };

#endif


